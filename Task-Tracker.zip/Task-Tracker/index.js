const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
const { log } = require('console');

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.get("/", function (req, res) {
    fs.readdir('./files', function (err, files) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
              res.render('index', { files: files });
        }
    });
});
app.get("/files/:filename", function (req, res) {
    fs.readFile(`./files/${req.params.filename}`, "utf-8", function (err, filedata) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
              res.render('show.ejs',{filename:req.params.filename,filedata:filedata});
        }
    });
});
app.get("/edit/:filename", function (req, res) {
    fs.readFile(`./files/${req.params.filename}`, "utf-8", function (err, filedata) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
              res.render('edit.ejs',{filename:req.params.filename,filedata:filedata});
        }
    });
});
app.get("/", function (req, res) {
    fs.readFile(`./files/${req.params.filename}`, "utf-8", function (err, filedata) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
              res.render('index');
        }
    });
});



app.post("/create", function (req, res) {
    const title = req.body.title.split(' ').join('');
    const content = req.body.details;
    fs.writeFile(`./files/${title}.txt`, content, function (err) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.redirect("/");
        }
    });
  
});

app.post("/edit/:filename", function (req, res) {
    const oldFilename = `./files/${req.params.filename}`;
    const newFilename = `./files/${req.body.newTitle.split(' ').join('')}.txt`;
    const content = req.body.details;

    fs.rename(oldFilename, newFilename, function (err) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            fs.writeFile(newFilename, content, function (err) {
                if (err) {
                    console.error(err);
                    res.status(500).send('Internal Server Error');
                } else {
                    res.redirect("/");
                }
            });
        }
    });
});

app.post("/delete/:filename", function (req, res) {
    fs.unlink(`./files/${req.params.filename}`, function (err) {
        if (err) {
            console.error(err);
            res.status(500).send('Internal Server Error');
        } else {
            res.redirect("/");
        }
    });
});

app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).send('Something broke!');
});

app.listen(9000, () => {
    console.log('Server is running on http://localhost:9000');
});
